// 1

const inputFirst = document.querySelector('.inputFirst')
const outputFirst = document.querySelector('.outputFirst')

inputFirst.addEventListener('input', function() {
    outputFirst.textContent = inputFirst.value;
})

//2
const btnSecond = document.querySelector('.btnSecond')

btnSecond.addEventListener('click', function(){
    const items = document.querySelectorAll('.listSecond li:nth-child(2n)');
        items.forEach(item => {
            item.style.backgroundColor = item.style.backgroundColor == 'yellow' ? 'white' : 'yellow';
        });
})

//3
document.querySelector('.imgThird').addEventListener('click', () => {
    const img = document.querySelector('.imgThird');
    img.style.width = (img.offsetWidth + 10) + 'px';
});

//4
function clearDiv() {
    const parent = document.querySelector('.parent');
    parent.innerHTML = '';
}

//5

const inputFifth = document.querySelector('.inputFifth')
inputFifth.addEventListener('focus', () => {
    inputFifth.style.height = '40px';
});
inputFifth.addEventListener('blur', () => {
    inputFifth.style.height = '20px';
});

//6
const list = document.querySelector('.list')

addEventListener('keypress', (e) => {
    if (e.key === "q"){
        if (list.children.length < 5){
            list.innerHTML += `<li class="elem">${list.children.length + 1}</li>`
        }
    }
})

//7

document.querySelectorAll('.listSeventh li').forEach(item=>{
    item.addEventListener('click', () => {
        item.classList.toggle('active');
    })

})

//8
const timeOfDay = document.querySelector('.timeOfDay')
const hour = new Date().getHours();
if (hour < 12) {
    timeOfDay.textContent = 'Доброе утро!';
} else if (hour < 18) {
    timeOfDay.textContent = 'Добрый день!';
} else {
    timeOfDay.textContent = 'Добрый вечер!';
}

//9
const linkNinth = document.querySelector('.linkNinth')

linkNinth.addEventListener('click', (e)=>{
    e.preventDefault();
   

})

//10
function updateTime() {
    const now = new Date();
    document.querySelector('.currentTime').textContent = now.toLocaleTimeString();
}
setInterval(updateTime, 1000);
updateTime();

//11
document.addEventListener('mousemove', (e)=>{
    document.querySelector('.coord').textContent = `X: ${e.clientX}, Y: ${e.clientY}`;
})

//12
const imgTwelve = document.querySelector('.imgTwelve');
imgTwelve.addEventListener('mouseenter', () => {
    imgTwelve.src = '/images/zhuk3.jpg';
});
imgTwelve.addEventListener('mouseleave', () => {
    imgTwelve.src = '/images/zhuk2.png';
});
//13
function sortList() {
    const list = document.querySelector('.listThirdteen');
    const items = Array.from(list.querySelectorAll('li'));
    items.sort((a, b) => a.textContent.localeCompare(b.textContent));
    list.innerHTML = '';
    items.forEach(item => list.appendChild(item));
}

//14


document.querySelector('.selectFourthteen').addEventListener('change', (e) => {
    document.querySelector('.pFourthteen').textContent = e.target.value;
});

//15
const imageFifthteen = document.querySelector('.imageFifthteen');
imageFifthteen.addEventListener('click', () => {
    imageFifthteen.style.display = 'none'
});
